<?php
/**
 * koneksi.php — Koneksi database (MySQLi)
 * Default XAMPP: host localhost, user root, password kosong.
 */
mysqli_report(MYSQLI_REPORT_OFF); // error ditangani manual agar pesan tetap ramah

define('BASE_URL', '/rekam_medis'); // ubah jika nama folder di htdocs berbeda

$db_host = 'localhost';
$db_user = 'bima';
$db_pass = 'LANTAI';
$db_name = 'db_rekam_medis';

$koneksi = @new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($koneksi->connect_errno) {
    http_response_code(500);
    die('<div style="font-family:system-ui;max-width:520px;margin:15vh auto;padding:28px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;color:#0f172a">
        <h2 style="margin:0 0 8px;color:#0d9488">Koneksi database gagal</h2>
        <p style="margin:0 0 12px;color:#475569">Pastikan Apache &amp; MySQL di XAMPP sudah aktif dan database <b>db_rekam_medis</b> sudah dibuat.</p>
        <code style="font-size:13px;color:#b91c1c">' . htmlspecialchars($koneksi->connect_error) . '</code></div>');
}

$koneksi->set_charset('utf8mb4');
